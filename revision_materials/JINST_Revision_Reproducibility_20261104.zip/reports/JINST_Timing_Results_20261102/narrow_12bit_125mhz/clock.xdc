create_clock -name clk -period 8.000000 [get_ports clk]
