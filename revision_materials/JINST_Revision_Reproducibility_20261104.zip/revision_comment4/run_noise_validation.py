#!/usr/bin/env python3
"""Independent noise calibration/validation for JINST comment 4.

One trial is one 500-sample window. Original mixed Geant4 data are read-only.
Threshold selection uses calibration data only; held-out results are not used
to revise thresholds. Both old and newly selected operating points are kept.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time
import zipfile

import numpy as np
import scipy
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
SIGMAS = (0.001, 0.003, 0.006)
BITS = (8, 10, 12)
TARGET = 0.001
ALPHA = 0.05
BASE_SEED = 20261103
FLOAT_GRID = np.arange(121, dtype=np.float64)/1000


def upper(k, n):
    """One-sided 95% Clopper-Pearson upper bound, per configuration."""
    if k == n:
        return 1.0
    if k == 0:
        return -math.expm1(math.log(ALPHA)/n)
    return float(beta.ppf(1-ALPHA, k+1, n-k))


def save_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def score(q, bits):
    """Exact old normalized criterion and integer HDL event criterion."""
    normalized = q.astype(np.float32)/(2**bits-1)
    floating = normalized.max(axis=1)-normalized[:, :40].mean(axis=1)
    baseline_integer = q[:, :40].astype(np.uint64).sum(axis=1)//40
    integer = q[:, 40:].max(axis=1).astype(np.int64)-baseline_integer.astype(np.int64)
    return floating.astype(np.float64), integer


def noise_scores(n, phase, noise_index, batch):
    """Same analog windows across ADC resolutions, separate RNG per phase/noise."""
    sigma = SIGMAS[noise_index]
    rng = np.random.default_rng(np.random.SeedSequence([BASE_SEED, 4, phase, noise_index]))
    values = {b: [np.empty(n, np.float64), np.empty(n, np.int64)] for b in BITS}
    digests = {b: hashlib.sha256() for b in BITS}
    for first in range(0, n, batch):
        last = min(n, first+batch)
        noise = rng.normal(0., sigma, (last-first, 500)).astype(np.float32)
        analog = np.clip(np.float32(0.1)+noise, 0., 1.)
        for bits in BITS:
            q = np.rint(analog*(2**bits-1)).astype(np.uint16)
            f, integer = score(q, bits)
            values[bits][0][first:last] = f
            values[bits][1][first:last] = integer
            # Canonical little-endian ADC bytes; SHA covers actual generated windows.
            digests[bits].update(q.astype('<u2', copy=False).tobytes())
    return values, {str(b): d.hexdigest() for b,d in digests.items()}


def counts(scores, thresholds):
    ordered = np.sort(scores)
    return len(scores)-np.searchsorted(ordered, thresholds, side='left')


def legacy_thresholds():
    result = {}
    with (ROOT/'inputs/adc_noise_sweep_trigger_operating_points.csv').open(newline='') as stream:
        for row in csv.DictReader(stream):
            if float(row['false_trigger_constraint_percent']) == 0.1:
                s, b, t = float(row['noise_sigma_fraction']), int(row['adc_bits']), float(row['threshold_norm'])
                result[s,b] = {'normalized_float':t,'integer_hdl':int(round(t*(2**b-1)))}
    assert len(result)==9
    return result


def select(scores, definition, n):
    grid = FLOAT_GRID if definition=='normalized_float' else np.arange(int(scores.max())+2)
    k = counts(scores, grid)
    u = np.array([upper(int(x),n) for x in k])
    accepted = np.flatnonzero(u <= TARGET)
    if not len(accepted):
        raise RuntimeError('No calibration threshold meets the upper-bound criterion.')
    index = int(accepted[0])
    threshold = float(grid[index]) if definition=='normalized_float' else int(grid[index])
    return threshold, int(k[index]), float(u[index]), grid, k, u


def assess(scores, threshold, n):
    k = int(np.count_nonzero(scores >= threshold))
    bound = upper(k,n)
    return {'false_triggers':k,'windows':n,'false_trigger_percent':100*k/n,
            'upper95_percent':100*bound, 'target_percent':100*TARGET,
            'meets_pointwise_upper95_target':bound <= TARGET}


def signal_validation(selected, old, batch):
    """Fresh signal-noise draws independent of noise calibration and test sets."""
    with (ROOT/'inputs/waveform_labels.csv').open(newline='') as stream:
        data = list(csv.DictReader(stream))
    energy = np.array([float(row['edep_nai_keV']) for row in data])
    amplitude = np.array([float(row['true_amplitude_norm']) for row in data])
    nonzero = energy > 0
    full = energy > 58
    partial = nonzero & ~full
    assert len(data)==100000 and nonzero.sum()==99891
    time_ns = np.arange(500)*4.-200
    shape = np.zeros(500)
    valid = time_ns>=0
    shape[valid] = (1-np.exp(-time_ns[valid]/20))*np.exp(-time_ns[valid]/250)
    shape /= shape.max()
    output=[]
    for noise_index, sigma in enumerate(SIGMAS):
        rng = np.random.default_rng(np.random.SeedSequence([BASE_SEED,4,2,noise_index]))
        passed = {(b,definition,choice):np.zeros(len(data),bool)
                  for b in BITS for definition in ['normalized_float','integer_hdl'] for choice in ['legacy','calibrated']}
        for first in range(0,len(data),batch):
            last=min(first+batch,len(data))
            clean=(.1+amplitude[first:last,None]*shape[None,:]).astype(np.float32)
            noise=rng.normal(0.,sigma,(last-first,500)).astype(np.float32)
            analog=np.clip(clean+noise,0,1)
            for bits in BITS:
                q=np.rint(analog*(2**bits-1)).astype(np.uint16)
                f,integer=score(q,bits)
                for definition,values in [('normalized_float',f),('integer_hdl',integer)]:
                    for choice,threshold in [('legacy',old[sigma,bits][definition]),
                                             ('calibrated',selected[sigma,bits,definition]['threshold'])]:
                        passed[bits,definition,choice][first:last]=values>=threshold
        for key,decisions in passed.items():
            b,definition,choice=key
            for subset,mask in [('nonzero',nonzero),('full_energy_like',full),('partial',partial)]:
                output.append({'noise_sigma':sigma,'adc_bits':b,'criterion':definition,'threshold_source':choice,
                               'event_subset':subset,'events':int(mask.sum()),'triggered':int(decisions[mask].sum()),
                               'efficiency_percent':100*float(decisions[mask].mean())})
        print(f'Signal-efficiency check finished: sigma={sigma}',flush=True)
    return output


def self_test():
    assert abs(upper(0,109)-0.027109539554339923)<1e-14
    assert abs(upper(0,100000)-0.00002995687401942796)<1e-14
    assert upper(10,1000)>upper(0,1000) and upper(100,100)==1
    from scipy.stats import binom
    assert abs(binom.cdf(10,1000,upper(10,1000))-.05)<1e-10
    q=np.array([[0,1,2,3,4,5,6,7]*63],dtype=np.uint16)[:,:500]
    for b in BITS:
        f,integer=score(q,b)
        expected=int(max(q[0,40:]))-sum(map(int,q[0,:40]))//40
        assert int(integer[0])==expected
        assert np.array_equal(counts(np.array([1,2,2,3]),np.array([2,3,4])),np.array([3,1,0]))
    a,hash_a=noise_scores(300,0,0,64)
    b,hash_b=noise_scores(300,0,0,137)
    assert hash_a==hash_b
    assert all(np.array_equal(a[x][j],b[x][j]) for x in BITS for j in [0,1])
    _,hash_test=noise_scores(300,1,0,64)
    assert hash_a!=hash_test


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'results'/time.strftime('run_%Y%m%d_%H%M%S'))
    parser.add_argument('--windows',type=int,default=100000)
    parser.add_argument('--batch',type=int,default=1024)
    parser.add_argument('--self-test-only',action='store_true')
    args=parser.parse_args()
    self_test()
    print('Self-checks passed.',flush=True)
    if args.self_test_only: return
    if args.windows < 2995 or args.batch < 1: parser.error('Use at least 2995 windows and a positive batch size.')
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    old=legacy_thresholds()
    selected={};curves=[];digests={}
    started=time.monotonic()
    print('CALIBRATION: independent noise windows; thresholds selected only here.',flush=True)
    for noise_index,sigma in enumerate(SIGMAS):
        values,hashes=noise_scores(args.windows,0,noise_index,args.batch)
        digests[f'calibration_{sigma}']=hashes
        for bits in BITS:
            for definition,scores in zip(['normalized_float','integer_hdl'],values[bits]):
                t,k,u,grid,observed,bounds=select(scores,definition,args.windows)
                selected[sigma,bits,definition]={'threshold':t,'false_triggers':k,'upper95_percent':100*u}
                curves.extend({'noise_sigma':sigma,'adc_bits':bits,'criterion':definition,'threshold':float(g),
                               'false_triggers':int(c),'windows':args.windows,'upper95_percent':100*float(bound)}
                              for g,c,bound in zip(grid,observed,bounds))
        print(f'Calibration finished: sigma={sigma}, windows={args.windows}',flush=True)
    frozen=[{'noise_sigma':s,'adc_bits':b,'criterion':definition,**value} for (s,b,definition),value in selected.items()]
    (out/'frozen_thresholds.json').write_text(json.dumps(frozen,indent=2)+'\n')
    # All operating points are frozen before generating independent validation data.
    validation=[]
    print('VALIDATION: new independent noise; no further threshold tuning.',flush=True)
    for noise_index,sigma in enumerate(SIGMAS):
        values,hashes=noise_scores(args.windows,1,noise_index,args.batch)
        digests[f'validation_{sigma}']=hashes
        for bits in BITS:
            for definition,scores in zip(['normalized_float','integer_hdl'],values[bits]):
                chosen=selected[sigma,bits,definition]
                for choice,t in [('legacy',old[sigma,bits][definition]),('calibrated',chosen['threshold'])]:
                    validation.append({'noise_sigma':sigma,'adc_bits':bits,'criterion':definition,'threshold_source':choice,
                                       'threshold':t,'calibration_false_triggers':chosen['false_triggers'] if choice=='calibrated' else '',
                                       **assess(scores,t,args.windows)})
        print(f'Validation finished: sigma={sigma}, windows={args.windows}',flush=True)
    save_csv(out/'noise_validation.csv',validation)
    save_csv(out/'calibration_curves.csv',curves)
    efficiencies=signal_validation(selected,old,args.batch)
    save_csv(out/'signal_efficiency.csv',efficiencies)
    # One-sided pointwise limits; the table does not claim simultaneous coverage.
    protocol={'noise_windows_per_sigma_per_phase':args.windows,'independent_noise_windows_total':6*args.windows,
              'window_samples':500,'pretrigger_samples':40,'sample_interval_ns':4,'baseline_fraction':.1,
              'noise_sigmas':SIGMAS,'adc_bits':BITS,'target_probability':TARGET,'alpha':ALPHA,
              'confidence_method':'one-sided pointwise 95% exact Clopper-Pearson upper bound',
              'seed_namespace':[BASE_SEED,4,'phase=0 calibration / 1 validation / 2 signal','noise_index=0/1/2'],
              'dependence':'ADC resolutions share analog windows; do not pool their counts as independent trials.',
              'noise_model':'iid zero-mean Gaussian; float32 noise and baseline addition, clipping [0,1], np.rint ADC',
              'normalized_criterion':'max over all 500 normalized samples minus floating mean of first 40 >= threshold',
              'integer_criterion':'max over samples 40..499 minus floor(sum(first40)/40) >= threshold_counts',
              'calibration_rule':'lowest grid threshold with calibration upper95 <= 0.1%; frozen before validation',
              'retuning_on_validation':False,'batch':args.batch,'python':sys.version,'platform':platform.platform(),
              'numpy':np.__version__,'scipy':scipy.__version__,'elapsed_seconds':time.monotonic()-started,
              'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'inputs').iterdir()) if p.is_file()},
              'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'scope':'synthetic noise validation only; not hardware verification or non-Gaussian-noise robustness',
              'sources':{'NIST':'https://www.itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbino.htm',
                         'SciPy':'https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.beta.html'}}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (out/'generated_adc_sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
    chosen=[r for r in validation if r['threshold_source']=='calibrated']
    summary=['JINST Comment 4: completed independent noise validation.',
             f'Noise windows: {6*args.windows} total; {args.windows} per noise level per calibration/validation phase.',
             f'Calibrated criteria passing held-out upper95 <= 0.1%: {sum(r["meets_pointwise_upper95_target"] for r in chosen)}/{len(chosen)}.',
             'FAIL is a scientific result, not a program error; do not retune on this validation set.',
             'See noise_validation.csv for legacy and calibrated counts, proportions and confidence bounds.',
             'See signal_efficiency.csv for signal retention at both operating points.',
             'The original Geant4/mixed event population was not changed.']
    (out/'SUMMARY.txt').write_text('\n'.join(summary)+'\n')
    files=list(out.iterdir())
    manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files if f.is_file()}
    (out/'result_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=out/'JINST_Comment4_Results.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.iterdir()):
            if f.is_file() and f!=archive: z.write(f,f.name)
    with zipfile.ZipFile(archive) as z: assert z.testzip() is None
    print('\n'.join(summary),flush=True)
    print(f'\nRESULT FILE TO UPLOAD: {archive}',flush=True)


if __name__=='__main__': main()
