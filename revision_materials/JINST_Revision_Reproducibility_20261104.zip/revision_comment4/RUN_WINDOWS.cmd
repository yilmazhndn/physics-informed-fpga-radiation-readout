@echo off
setlocal
cd /d "%~dp0"
echo JINST Comment 4 - Independent noise calibration and validation
echo All working files and the Python environment stay in this folder.
set "JINST_PYTHON="
where py >nul 2>nul
if not errorlevel 1 set "JINST_PYTHON=py -3"
if not defined JINST_PYTHON (
  where python >nul 2>nul
  if not errorlevel 1 set "JINST_PYTHON=python"
)
if not defined JINST_PYTHON goto missing_python
%JINST_PYTHON% -c "import sys,struct; print(sys.version); assert (3,11) <= sys.version_info[:2] <= (3,14), 'Python 3.11-3.14 required for this tested package'; assert struct.calcsize('P')==8, '64-bit Python required'"
if errorlevel 1 goto missing_python
if not exist ".venv\Scripts\python.exe" (
  %JINST_PYTHON% -m venv ".venv"
  if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install --only-binary=:all: --no-cache-dir -r "requirements.txt"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -u "run_noise_validation.py"
if errorlevel 1 goto failed
echo.
echo Completed. Upload the JINST_Comment4_Results.zip file printed above.
pause
exit /b 0
:missing_python
echo.
echo Python 3.11-3.14 was not found. Do not install anything yet.
echo Copy this message to ChatGPT so the next step can be checked.
pause
exit /b 1
:failed
echo.
echo The run stopped. Keep this window open and send the last error lines.
pause
exit /b 1
