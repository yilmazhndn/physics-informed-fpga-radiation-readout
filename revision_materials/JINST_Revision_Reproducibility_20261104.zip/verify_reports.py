#!/usr/bin/env python3
"""Audit the received Vivado reports; keep primitive and physical LUT counts separate.

Usage: python3 verify_reports.py PATH_TO_JINST_Timing_Results_20261102 OUTPUT_DIR
No FPGA tools are invoked. Assertions compare reports with the original CSV.
"""
import csv
import hashlib
import json
from pathlib import Path
import re
import sys


def extract(root):
    rows = []
    for row in csv.DictReader((root / 'comparison.csv').open()):
        run = root / f"{row['variant']}_{row['adc_bits']}bit_{row['clock_mhz']}mhz"
        summary = (run / 'timing_summary.rpt').read_text()
        util = (run / 'utilization.rpt').read_text()
        setup = (run / 'setup_paths.rpt').read_text()
        methodology = (run / 'methodology.rpt').read_text()
        assert 'Design State : Routed' in summary
        lines = summary[summary.index('| Design Timing Summary'):].splitlines()
        index = next(i for i, line in enumerate(lines) if 'WNS(ns)' in line)
        v = lines[index + 2].split()
        keys = ['wns_ns', 'tns_ns', 'setup_failing_endpoints', 'setup_total_endpoints',
                'whs_ns', 'ths_ns', 'hold_failing_endpoints', 'hold_total_endpoints',
                'wpws_ns', 'tpws_ns', 'pulse_width_failing_endpoints', 'pulse_width_total_endpoints']
        for key, value in zip(keys, v):
            row[key] = float(value) if key.endswith('_ns') else int(value)
        assert row['wns_ns'] == float(row['setup_wns_ns'])
        assert row['whs_ns'] == float(row['hold_whs_ns'])
        for key, label in [('slice_luts', 'Slice LUTs'), ('slice_registers', 'Slice Registers'),
                           ('lut_as_logic', 'LUT as Logic'), ('lut_as_memory', 'LUT as Memory'),
                           ('lut_as_shift_register', 'LUT as Shift Register'),
                           ('block_ram_tiles', 'Block RAM Tile'), ('dsps', 'DSPs')]:
            match = re.search(r'\|\s*' + re.escape(label) + r'\s*\|\s*(\d+)', util)
            row[key] = int(match.group(1)) if match else 0
        assert row['slice_luts'] == row['lut_as_logic'] + row['lut_as_memory']
        assert row['slice_registers'] == int(row['ff_primitives'])
        for label in ['no_clock', 'unconstrained_internal_endpoints', 'no_input_delay',
                      'no_output_delay', 'loops', 'latch_loops']:
            row[label] = int(re.search(r'checking ' + label + r' \((\d+)\)', summary).group(1))
        assert row['no_clock'] == row['unconstrained_internal_endpoints'] == row['loops'] == row['latch_loops'] == 0
        assert row['no_input_delay'] == 15 and row['no_output_delay'] == 42
        row['methodology_rules'] = ';'.join(sorted(set(re.findall(r'\|\s*(TIMING-\d+)\s*\|', methodology))))
        setup = setup[setup.index('Slack ('):]
        for key, label in [('critical_source', 'Source'), ('critical_destination', 'Destination'),
                           ('critical_data_path_delay', 'Data Path Delay'), ('critical_logic_levels', 'Logic Levels')]:
            row[key] = re.search(r'^\s*' + label + r':\s*(.*)', setup, re.M).group(1).strip()
        expected_period = 1000 / int(row['clock_mhz'])
        xdc = (run / 'clock.xdc').read_text().strip()
        assert float(re.search(r'-period\s+([0-9.]+)', xdc).group(1)) == expected_period
        assert xdc.count('\n') == 0 and xdc.startswith('create_clock ')
        if row['status'] == 'INTERNAL_SETUP_HOLD_MET':
            assert row['wns_ns'] >= 0 and row['whs_ns'] >= 0
            assert row['setup_failing_endpoints'] == row['hold_failing_endpoints'] == row['pulse_width_failing_endpoints'] == 0
            assert row['tns_ns'] == row['ths_ns'] == row['tpws_ns'] == 0
            assert row['methodology_rules'] == 'TIMING-18'
            assert 'All user specified timing constraints are met.' in summary
        else:
            assert row['wns_ns'] < 0 and row['setup_failing_endpoints'] > 0
        rows.append(row)
    assert len(rows) == 8
    assert not list(root.rglob('error.txt'))
    return rows


def main():
    root, output = map(Path, sys.argv[1:3])
    rows = extract(root)
    output.mkdir(parents=True, exist_ok=True)
    with (output / 'verified_comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output / 'verified_comparison.json').write_text(json.dumps(rows, indent=2) + '\n')
    hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(root.rglob('*')) if p.is_file()}
    (output / 'received_report_sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')
    print('VERIFIED: eight report sets; CSV/report agreement; constraints coverage; resources; setup/hold/pulse-width results.')


if __name__ == '__main__':
    main()
