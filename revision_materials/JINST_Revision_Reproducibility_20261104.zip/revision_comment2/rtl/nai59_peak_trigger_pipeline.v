// Exact unsigned baseline division, explicitly pipelined.
// Retains the original 40-sample baseline and integer truncation semantics.
// Every external output is delayed DIV_STAGES+2 clocks relative to the original.
// Accepts one sample per clock; valid gaps and event_start markers are delayed
// together with the sample and its index. No post-baseline samples are dropped.
`timescale 1ns/1ps
module nai59_peak_trigger_pipeline #(
    parameter integer SAMPLE_BITS = 12,
    parameter integer N_SAMPLES = 500,
    parameter integer PRETRIGGER_SAMPLES = 40,
    parameter integer THRESHOLD_COUNTS = 61,
    parameter integer DIV_BITS_PER_STAGE = 3
)(
    input wire clk, rst, event_start, sample_valid,
    input wire [SAMPLE_BITS-1:0] sample_in,
    output reg event_done, triggered,
    output reg [SAMPLE_BITS-1:0] peak_count,
    output reg [15:0] peak_index,
    output reg [SAMPLE_BITS-1:0] baseline_count
);
    localparam integer SUM_W = SAMPLE_BITS + $clog2(PRETRIGGER_SAMPLES);
    localparam integer REM_W = $clog2(PRETRIGGER_SAMPLES) + 1;
    localparam integer TRIG_W = $clog2((2**SAMPLE_BITS) + THRESHOLD_COUNTS);
    localparam integer DIV_STAGES = (SUM_W + DIV_BITS_PER_STAGE - 1) / DIV_BITS_PER_STAGE;
    localparam integer META_STAGES = DIV_STAGES + 2;
    localparam integer OUTPUT_LATENCY = DIV_STAGES + 2;
    localparam [REM_W-1:0] DIVISOR = PRETRIGGER_SAMPLES;

    reg [15:0] raw_index;
    reg [SUM_W-1:0] raw_sum, sum_snapshot;
    wire [SUM_W-1:0] sum_next = raw_sum + sample_in;

    reg [META_STAGES-1:0] valid_pipe, start_pipe;
    reg [SAMPLE_BITS-1:0] sample_pipe [0:META_STAGES-1];
    reg [15:0] index_pipe [0:META_STAGES-1];
    integer m;
    always @(posedge clk) begin
        if (rst) begin
            raw_index <= 0;
            raw_sum <= 0;
            sum_snapshot <= 0;
            valid_pipe <= 0;
            start_pipe <= 0;
            for (m=0; m<META_STAGES; m=m+1) begin
                sample_pipe[m] <= 0;
                index_pipe[m] <= 0;
            end
        end else begin
            valid_pipe <= {valid_pipe[META_STAGES-2:0], sample_valid};
            start_pipe <= {start_pipe[META_STAGES-2:0], event_start};
            sample_pipe[0] <= sample_in;
            index_pipe[0] <= raw_index;
            for (m=1; m<META_STAGES; m=m+1) begin
                sample_pipe[m] <= sample_pipe[m-1];
                index_pipe[m] <= index_pipe[m-1];
            end
            if (event_start) begin
                raw_index <= 0;
                raw_sum <= 0;
                sum_snapshot <= 0;
            end else if (sample_valid) begin
                raw_index <= raw_index + 16'd1;
                if (raw_index < PRETRIGGER_SAMPLES) begin
                    raw_sum <= sum_next;
                    sum_snapshot <= sum_next;
                end
            end
        end
    end

    // Restoring integer division. Each stage resolves a small, fixed number
    // of quotient bits, giving an exact quotient with no reciprocal error.
    reg [SUM_W-1:0] numerator [0:DIV_STAGES-1];
    reg [SUM_W-1:0] quotient [0:DIV_STAGES-1];
    reg [REM_W-1:0] remainder [0:DIV_STAGES-1];
    genvar s;
    generate for (s=0; s<DIV_STAGES; s=s+1) begin: divide_stage
        localparam integer HIGH_BIT = SUM_W - 1 - s*DIV_BITS_PER_STAGE;
        localparam integer LOW_BIT = (HIGH_BIT-DIV_BITS_PER_STAGE+1 < 0)
                                    ? 0 : HIGH_BIT-DIV_BITS_PER_STAGE+1;
        wire [SUM_W-1:0] n_in;
        wire [SUM_W-1:0] q_in;
        wire [REM_W-1:0] r_in;
        if (s==0) begin: first
            assign n_in = sum_snapshot;
            assign q_in = {SUM_W{1'b0}};
            assign r_in = {REM_W{1'b0}};
        end else begin: later
            assign n_in = numerator[s-1];
            assign q_in = quotient[s-1];
            assign r_in = remainder[s-1];
        end
        reg [SUM_W-1:0] q_work;
        reg [REM_W-1:0] r_work;
        integer b;
        always @* begin
            q_work = q_in;
            r_work = r_in;
            for (b=HIGH_BIT; b>=LOW_BIT; b=b-1) begin
                r_work = (r_work << 1) | n_in[b];
                if (r_work >= DIVISOR) begin
                    r_work = r_work - DIVISOR;
                    q_work[b] = 1'b1;
                end else begin
                    q_work[b] = 1'b0;
                end
            end
        end
        always @(posedge clk) begin
            if (rst) begin
                numerator[s] <= 0;
                quotient[s] <= 0;
                remainder[s] <= 0;
            end else begin
                numerator[s] <= n_in;
                quotient[s] <= q_work;
                remainder[s] <= r_work;
            end
        end
    end endgenerate

    reg [SAMPLE_BITS-1:0] average_pipe;
    reg [TRIG_W-1:0] threshold_pipe, trigger_level;
    always @(posedge clk) begin
        if (rst) begin
            average_pipe <= 0;
            threshold_pipe <= 0;
        end else begin
            average_pipe <= quotient[DIV_STAGES-1][SAMPLE_BITS-1:0];
            threshold_pipe <= {1'b0, quotient[DIV_STAGES-1][SAMPLE_BITS-1:0]}
                              + THRESHOLD_COUNTS;
        end
    end

    wire [SAMPLE_BITS-1:0] aligned_sample = sample_pipe[META_STAGES-1];
    wire [15:0] aligned_index = index_pipe[META_STAGES-1];
    always @(posedge clk) begin
        if (rst) begin
            event_done <= 0;
            triggered <= 0;
            peak_count <= 0;
            peak_index <= 0;
            baseline_count <= 0;
            trigger_level <= 0;
        end else begin
            event_done <= 0;
            if (start_pipe[META_STAGES-1]) begin
                triggered <= 0;
                peak_count <= 0;
                peak_index <= 0;
                baseline_count <= 0;
                trigger_level <= 0;
            end else if (valid_pipe[META_STAGES-1]) begin
                if (aligned_index == 0 || aligned_sample > peak_count) begin
                    peak_count <= aligned_sample;
                    peak_index <= aligned_index;
                end
                if (aligned_index == PRETRIGGER_SAMPLES-1) begin
                    baseline_count <= average_pipe;
                    trigger_level <= threshold_pipe;
                end else if (aligned_index >= PRETRIGGER_SAMPLES) begin
                    if (aligned_sample >= trigger_level) triggered <= 1;
                end
                if (aligned_index == N_SAMPLES-1) event_done <= 1;
            end
        end
    end

`ifndef SYNTHESIS
    initial begin
        if (SAMPLE_BITS < 1 || SAMPLE_BITS > 16 || PRETRIGGER_SAMPLES < 1 ||
            PRETRIGGER_SAMPLES > N_SAMPLES || N_SAMPLES > 65535 ||
            THRESHOLD_COUNTS < 0 || THRESHOLD_COUNTS >= 2**SAMPLE_BITS ||
            DIV_BITS_PER_STAGE < 1) $fatal(1, "Unsupported parameter combination");
    end
`endif
endmodule
