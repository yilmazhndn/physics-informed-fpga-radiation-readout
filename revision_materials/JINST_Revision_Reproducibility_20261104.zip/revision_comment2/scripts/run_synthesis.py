#!/usr/bin/env python3
"""Open-source XC7 mapping only; NEVER a Vivado timing or utilization result."""
import concurrent.futures
import collections
import csv
from functools import lru_cache
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
RESULTS=ROOT/'results'
YOSYS=os.environ.get('YOSYS',shutil.which('yosys') or 'yosys')

def metrics(path,top):
    module=json.loads(path.read_text())['modules'][top]
    cells=module['cells']
    counts=collections.Counter(c['type'] for c in cells.values())
    drivers={}
    def sequential(t): return t.startswith(('FD','LD','RAM','DSP','SRL'))
    for name,c in cells.items():
        for port,direction in c['port_directions'].items():
            if direction=='output':
                for bit in c['connections'][port]:
                    if isinstance(bit,int): drivers[bit]=name
    visiting=set()
    @lru_cache(None)
    def depth(bit):
        if not isinstance(bit,int) or bit not in drivers:return 0
        name=drivers[bit];c=cells[name]
        if sequential(c['type']):return 0
        if bit in visiting:raise ValueError('Unexpected combinational loop')
        visiting.add(bit)
        ins=[b for p,bs in c['connections'].items() if c['port_directions'][p]=='input' for b in bs]
        value=1+max((depth(b) for b in ins),default=0)
        visiting.remove(bit)
        return value
    # Each CARRY4/LUT/MUX counts as one mapped combinational cell. All pins of
    # a cell are conservatively treated as dependent. No routing/time weights.
    ends=[b for c in cells.values() if c['type'].startswith('FD')
          for b in c['connections'].get('D',[])]
    return {'lut_cells':sum(v for k,v in counts.items() if k.startswith('LUT')),
            'flipflops':sum(v for k,v in counts.items() if k.startswith('FD')),
            'carry4':counts.get('CARRY4',0),'dsp48':counts.get('DSP48E1',0),
            'max_conservative_cell_levels_to_D':max(map(depth,ends),default=0),
            'all_cell_counts':dict(counts)}

def run_job(config):
    variant,bits,threshold,group=config
    top='nai59_peak_trigger_'+('pipeline' if group else variant)
    name=f'{variant}_{bits}bit'
    src=ROOT/'rtl'/(top+'.v')
    out=RESULTS/(name+'_mapped.json')
    log=RESULTS/(name+'_synthesis.log')
    if not (variant=='original' and bits==12 and out.exists()):
        script=f'read_verilog -sv {src}; chparam -set SAMPLE_BITS {bits} -set THRESHOLD_COUNTS {threshold}'
        if group:script+=f' -set DIV_BITS_PER_STAGE {group}'
        script+=f' {top}; synth_xilinx -family xc7 -top {top} -noclkbuf -noiopad; stat; check; write_json {out}'
        process=subprocess.run([YOSYS,'-Q','-T','-q','-l',str(log),'-p',script],text=True,capture_output=True)
        if process.returncode:raise RuntimeError(name+': '+process.stderr[-2000:])
    result={'variant':variant,'bits':bits,'threshold':threshold,'tool':'Yosys XC7 mapping',
            'physical_timing_verified':False,**metrics(out,top)}
    print(json.dumps(result),flush=True)
    return result

def main():
    configs=[(v,b,t,g) for b,t in [(8,4),(10,15),(12,61)]
             for v,g in [('original',0),('narrow',0),('pipeline2',2),('pipeline3',3)]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results=list(pool.map(run_job,configs))
    (RESULTS/'synthesis.json').write_text(json.dumps(results,indent=2)+'\n')
    simple=[{k:v for k,v in r.items() if k!='all_cell_counts'} for r in results]
    with (RESULTS/'synthesis.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(simple[0]));w.writeheader();w.writerows(simple)
    print('ALL_STRUCTURAL_SYNTHESIS_RUNS_COMPLETE',flush=True)

if __name__=='__main__':main()
