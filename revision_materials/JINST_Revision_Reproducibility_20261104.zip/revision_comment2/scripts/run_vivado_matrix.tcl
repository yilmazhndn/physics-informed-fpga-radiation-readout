# Run with Vivado 2026.1 (or record another version explicitly):
# vivado -mode batch -source scripts/run_vivado_matrix.tcl
# Optional: -tclargs OUTPUT_DIR ALL_BITS OPTIONAL_BOARD_XDC
# Default is 12-bit, all four variants, 250 and 125 MHz (8 routed runs).
# No board I/O timing is invented. Without OPTIONAL_BOARD_XDC, results are
# explicitly internal/core timing only, not full interface/board sign-off.
set root [file normalize [file join [file dirname [info script]] ..]]
set outdir [file join $root results vivado]
if {[llength $argv]>0} {set outdir [file normalize [lindex $argv 0]]}
set all_bits 0
if {[llength $argv]>1} {set all_bits [lindex $argv 1]}
set board_xdc ""
if {[llength $argv]>2} {set board_xdc [file normalize [lindex $argv 2]]}
if {$board_xdc ne "" && ![file exists $board_xdc]} {error "Board XDC not found"}
file mkdir $outdir
set manifest [open [file join $outdir environment.txt] w]
puts $manifest "Vivado: [version -short]"
puts $manifest "Part: xc7a35tcpg236-1"
puts $manifest "Flow: synth_design; opt_design; place_design; phys_opt_design; route_design"
puts $manifest "Board XDC: $board_xdc"
puts $manifest "Without board XDC: internal timing assessment only; I/O paths remain unconstrained."
puts $manifest "These new controlled comparisons do not exactly reproduce undocumented historical run settings."
close $manifest

set table [open [file join $outdir comparison.csv] w]
puts $table "variant,adc_bits,clock_mhz,latency_clocks,setup_wns_ns,hold_whs_ns,lut_primitives,ff_primitives,dsp_primitives,bram_primitives,scope,status"
flush $table
set bit_list {12}
if {$all_bits} {set bit_list {8 10 12}}
set variants {original narrow pipeline2 pipeline3}
foreach bits $bit_list {
    set threshold 61
    if {$bits==8} {set threshold 4}
    if {$bits==10} {set threshold 15}
    foreach variant $variants {
        foreach mhz {250 125} {
            set run_dir [file join $outdir ${variant}_${bits}bit_${mhz}mhz]
            file mkdir $run_dir
            set top nai59_peak_trigger_$variant
            set group 0
            if {$variant eq "pipeline2"} {set top nai59_peak_trigger_pipeline;set group 2}
            if {$variant eq "pipeline3"} {set top nai59_peak_trigger_pipeline;set group 3}
            set latency 0
            if {$group} {
                set sum_w [expr {$bits+int(ceil(log(40)/log(2)))}]
                set latency [expr {int(ceil(double($sum_w)/$group))+2}]
            }
            set status ERROR
            set scope internal_only
            if {$board_xdc ne ""} {set scope board_constraints_supplied}
            if {[catch {
                create_project -in_memory -part xc7a35tcpg236-1
                read_verilog [file join $root rtl ${top}.v]
                set clock_xdc [file join $run_dir clock.xdc]
                set clock_file [open $clock_xdc w]
                puts $clock_file [format {create_clock -name clk -period %.6f [get_ports clk]} [expr {1000.0/$mhz}]]
                close $clock_file
                read_xdc $clock_xdc
                if {$board_xdc ne ""} {read_xdc $board_xdc}
                set generics [list SAMPLE_BITS=$bits N_SAMPLES=500 PRETRIGGER_SAMPLES=40 THRESHOLD_COUNTS=$threshold]
                if {$group} {lappend generics DIV_BITS_PER_STAGE=$group}
                synth_design -top $top -part xc7a35tcpg236-1 -generic $generics
                opt_design
                place_design
                phys_opt_design
                route_design
                report_timing_summary -check_timing_verbose -report_unconstrained -max_paths 10 -file [file join $run_dir timing_summary.rpt]
                report_timing -delay_type max -max_paths 10 -file [file join $run_dir setup_paths.rpt]
                report_timing -delay_type min -max_paths 10 -file [file join $run_dir hold_paths.rpt]
                report_utilization -file [file join $run_dir utilization.rpt]
                report_methodology -file [file join $run_dir methodology.rpt]
                write_checkpoint -force [file join $run_dir routed.dcp]
                set setup_paths [get_timing_paths -delay_type max -max_paths 1]
                set hold_paths [get_timing_paths -delay_type min -max_paths 1]
                if {![llength $setup_paths] || ![llength $hold_paths]} {error "Missing setup/hold timing paths"}
                set wns [get_property SLACK [lindex $setup_paths 0]]
                set whs [get_property SLACK [lindex $hold_paths 0]]
                set luts [llength [get_cells -hier -filter {REF_NAME =~ LUT*}]]
                set ffs [llength [get_cells -hier -filter {REF_NAME =~ FD*}]]
                set dsps [llength [get_cells -hier -filter {REF_NAME =~ DSP*}]]
                set brams [llength [get_cells -hier -filter {REF_NAME =~ RAMB*}]]
                set status INTERNAL_TIMING_FAIL
                if {$wns>=0 && $whs>=0} {set status INTERNAL_SETUP_HOLD_MET}
                puts $table "$variant,$bits,$mhz,$latency,$wns,$whs,$luts,$ffs,$dsps,$brams,$scope,$status"
                flush $table
            } message options]} {
                set f [open [file join $run_dir error.txt] w]
                puts $f $message
                if {[dict exists $options -errorinfo]} {puts $f [dict get $options -errorinfo]}
                close $f
                puts $table "$variant,$bits,$mhz,$latency,,,,,,,${scope},ERROR"
                flush $table
            }
            catch {close_project}
        }
    }
}
close $table
puts "Completed comparison. Review timing_summary.rpt and methodology.rpt, including constraints coverage."
