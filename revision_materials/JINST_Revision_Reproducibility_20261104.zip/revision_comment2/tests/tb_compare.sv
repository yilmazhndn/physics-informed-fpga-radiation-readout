`timescale 1ns/1ps
module tb_compare;
    parameter integer SAMPLE_BITS=12, N_SAMPLES=500, PRETRIGGER_SAMPLES=40;
    parameter integer THRESHOLD_COUNTS=61, REPLAY_EVENTS=1024, RANDOM_EVENTS=256;
    localparam integer MAX_ADC=(2**SAMPLE_BITS)-1;
    localparam integer SUM_W=SAMPLE_BITS+$clog2(PRETRIGGER_SAMPLES);
    localparam integer L2=(SUM_W+1)/2+2;
    localparam integer L3=(SUM_W+2)/3+2;
    localparam integer MAX_L=L2;
    localparam integer PACK_W=2*SAMPLE_BITS+18;
    reg clk=0;
    always #2 clk=~clk; // Functional RTL only: this is not physical timing verification.
    reg rst=1, event_start=0, sample_valid=0;
    reg [SAMPLE_BITS-1:0] sample_in=0;
    wire done[0:3], trigger_out[0:3];
    wire [SAMPLE_BITS-1:0] peak[0:3], baseline[0:3];
    wire [15:0] peak_idx[0:3];
    wire [PACK_W-1:0] packed_out[0:3];
    genvar v;
    generate for(v=0;v<4;v=v+1) begin: pack_output
        assign packed_out[v]={done[v],trigger_out[v],peak[v],peak_idx[v],baseline[v]};
    end endgenerate
`define PARAMS .SAMPLE_BITS(SAMPLE_BITS),.N_SAMPLES(N_SAMPLES),.PRETRIGGER_SAMPLES(PRETRIGGER_SAMPLES),.THRESHOLD_COUNTS(THRESHOLD_COUNTS)
`define PORTS(i) .clk(clk),.rst(rst),.event_start(event_start),.sample_valid(sample_valid),.sample_in(sample_in),.event_done(done[i]),.triggered(trigger_out[i]),.peak_count(peak[i]),.peak_index(peak_idx[i]),.baseline_count(baseline[i])
    nai59_peak_trigger_original #(`PARAMS) original_dut (`PORTS(0));
    nai59_peak_trigger_narrow #(`PARAMS) narrow_dut (`PORTS(1));
    nai59_peak_trigger_pipeline #(`PARAMS,.DIV_BITS_PER_STAGE(2)) pipe2_dut (`PORTS(2));
    nai59_peak_trigger_pipeline #(`PARAMS,.DIV_BITS_PER_STAGE(3)) pipe3_dut (`PORTS(3));
`undef PARAMS
`undef PORTS

    reg [PACK_W-1:0] history[0:MAX_L];
    integer cycles=0, errors=0, checked_events=0, j;
    always @(posedge clk) begin
        #0.001;
        if(rst) begin
            for(j=0;j<=MAX_L;j=j+1) history[j]=0;
        end else begin
            for(j=MAX_L;j>0;j=j-1) history[j]=history[j-1];
            history[0]=packed_out[0];
            cycles=cycles+1;
            if(packed_out[1] !== history[0] || packed_out[2] !== history[L2] ||
               packed_out[3] !== history[L3]) begin
                $display("CYCLE_MISMATCH cycle=%0d original=%h narrow=%h p2=%h expected2=%h p3=%h expected3=%h",
                    cycles,history[0],packed_out[1],packed_out[2],history[L2],packed_out[3],history[L3]);
                errors=errors+1;
                if(errors>10) $fatal(1,"Cycle equivalence failed");
            end
        end
    end

    task drive(input bit reset_v, input bit start_v, input bit valid_v,
               input integer sample_v);
        begin
            @(negedge clk);
            rst=reset_v; event_start=start_v; sample_valid=valid_v; sample_in=sample_v;
        end
    endtask

    reg [SAMPLE_BITS-1:0] replay_mem[0:1024*500-1];
    reg replay_trig[0:1023];
    reg [SAMPLE_BITS-1:0] replay_peak[0:1023];
    reg [15:0] replay_index[0:1023];
    reg [SAMPLE_BITS-1:0] event_data[0:N_SAMPLES-1];
    string vector_dir;
    integer seed=32'h1d2e3f40;
    integer evt,i,k,c,raw_value,base_value,expected_base,expected_peak,expected_idx;
    integer sum_value,expected_trigger;
    integer unsigned random_value;

    task score_event;
        begin
            sum_value=0; expected_peak=-1; expected_idx=0; expected_trigger=0;
            for(k=0;k<N_SAMPLES;k=k+1) begin
                if(k<PRETRIGGER_SAMPLES) sum_value=sum_value+event_data[k];
                if(k==0 || event_data[k]>expected_peak) begin
                    expected_peak=event_data[k]; expected_idx=k;
                end
            end
            expected_base=sum_value/PRETRIGGER_SAMPLES;
            for(k=PRETRIGGER_SAMPLES;k<N_SAMPLES;k=k+1)
                if(event_data[k]>=expected_base+THRESHOLD_COUNTS) expected_trigger=1;
        end
    endtask

    task send_event(input bit add_bubbles);
        integer t;
        begin
            score_event();
            drive(0,1,1,MAX_ADC); // event_start must take precedence over valid.
            for(t=0;t<N_SAMPLES;t=t+1) begin
                random_value=$urandom(seed);
                if(add_bubbles && random_value%7==0) drive(0,0,0,MAX_ADC);
                drive(0,0,1,event_data[t]);
            end
            drive(0,0,0,0);
            if(done[0] !== 1'b1 || baseline[0] !== expected_base[SAMPLE_BITS-1:0] ||
               peak[0] !== expected_peak[SAMPLE_BITS-1:0] || peak_idx[0] !== expected_idx[15:0] ||
               trigger_out[0] !== expected_trigger[0]) begin
                $display("ORACLE_MISMATCH event=%0d baseline=%0d/%0d peak=%0d/%0d index=%0d/%0d trig=%0d/%0d done=%0d",
                    checked_events,baseline[0],expected_base,peak[0],expected_peak,peak_idx[0],expected_idx,
                    trigger_out[0],expected_trigger,done[0]);
                $fatal(1,"Independent event oracle failed");
            end
            checked_events=checked_events+1;
        end
    endtask

    initial begin
        for(j=0;j<=MAX_L;j=j+1) history[j]=0;
        repeat(4) drive(1,0,0,0);
        drive(0,0,0,0);
        if(REPLAY_EVENTS>0) begin
            if(!$value$plusargs("VECTORS=%s",vector_dir)) $fatal(1,"Missing VECTORS path");
            $readmemh($sformatf("%s/nai59_%0dbit_flat.mem",vector_dir,SAMPLE_BITS),replay_mem);
            $readmemh($sformatf("%s/nai59_%0dbit_expected_trigger.mem",vector_dir,SAMPLE_BITS),replay_trig);
            $readmemh($sformatf("%s/nai59_%0dbit_expected_peak_count.mem",vector_dir,SAMPLE_BITS),replay_peak);
            $readmemh($sformatf("%s/nai59_%0dbit_expected_peak_index.mem",vector_dir,SAMPLE_BITS),replay_index);
            for(evt=0;evt<REPLAY_EVENTS;evt=evt+1) begin
                for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=replay_mem[evt*N_SAMPLES+i];
                send_event(0);
                if(trigger_out[0] !== replay_trig[evt] || peak[0] !== replay_peak[evt] ||
                   peak_idx[0] !== replay_index[evt]) $fatal(1,"Published label mismatch at %0d",evt);
            end
            $display("PUBLISHED_REPLAY PASS bits=%0d events=%0d",SAMPLE_BITS,REPLAY_EVENTS);
        end

        // Boundary cases: first eligible sample, final sample, tied maxima,
        // truncation, full-scale baseline, and overflowing threshold.
        for(c=0;c<12;c=c+1) begin
            base_value=MAX_ADC/3;
            for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=base_value;
            case(c)
                0: for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=0;
                1: for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=MAX_ADC;
                2: event_data[PRETRIGGER_SAMPLES]=base_value+THRESHOLD_COUNTS;
                3: event_data[N_SAMPLES-1]=MAX_ADC;
                4: begin event_data[PRETRIGGER_SAMPLES]=MAX_ADC;event_data[N_SAMPLES-1]=MAX_ADC;end
                5: event_data[0]=MAX_ADC;
                6: event_data[PRETRIGGER_SAMPLES-1]=base_value+1;
                7: begin
                    for(i=0;i<PRETRIGGER_SAMPLES;i=i+1) event_data[i]=MAX_ADC;
                    for(i=PRETRIGGER_SAMPLES;i<N_SAMPLES;i=i+1) event_data[i]=0;
                end
                8: for(i=PRETRIGGER_SAMPLES;i<N_SAMPLES;i=i+1)
                        event_data[i]=(THRESHOLD_COUNTS>0)?base_value+THRESHOLD_COUNTS-1:base_value;
                9: for(i=PRETRIGGER_SAMPLES;i<N_SAMPLES;i=i+1) event_data[i]=MAX_ADC;
                10: for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=(i%2)?MAX_ADC:0;
                11: begin
                    for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=0;
                    event_data[PRETRIGGER_SAMPLES-1]=MAX_ADC;
                    event_data[PRETRIGGER_SAMPLES]=MAX_ADC;
                end
            endcase
            send_event(c%2);
        end
        for(evt=0;evt<RANDOM_EVENTS;evt=evt+1) begin
            random_value=$urandom(seed); base_value=random_value%(MAX_ADC+1);
            for(i=0;i<N_SAMPLES;i=i+1) begin
                random_value=$urandom(seed);
                raw_value=base_value+(random_value%17)-8;
                if(i>=PRETRIGGER_SAMPLES && evt%3!=0)
                    raw_value=base_value+(random_value%(2*THRESHOLD_COUNTS+17))-8;
                if(raw_value<0) raw_value=0;
                if(raw_value>MAX_ADC) raw_value=MAX_ADC;
                event_data[i]=raw_value;
            end
            send_event(1);
        end

        // Abort/restart and synchronous reset at and around the divider launch.
        for(c=0;c<10;c=c+1) begin
            drive(0,1,0,0);
            for(i=0;i<PRETRIGGER_SAMPLES-2+c;i=i+1) drive(0,0,1,(i*13)% (MAX_ADC+1));
            if(c%2) begin
                drive(1,0,1,MAX_ADC);
                drive(0,0,0,0);
            end
            for(i=0;i<N_SAMPLES;i=i+1) event_data[i]=(i*7+c)%(MAX_ADC+1);
            send_event(1);
        end
        repeat(MAX_L+4) drive(0,0,0,0);
        if(errors) $fatal(1,"FAIL errors=%0d",errors);
        $display("RESULT PASS bits=%0d pre=%0d threshold=%0d events=%0d cycles=%0d latency_p2=%0d latency_p3=%0d mismatches=%0d",
            SAMPLE_BITS,PRETRIGGER_SAMPLES,THRESHOLD_COUNTS,checked_events,cycles,L2,L3,errors);
        $finish;
    end
endmodule
