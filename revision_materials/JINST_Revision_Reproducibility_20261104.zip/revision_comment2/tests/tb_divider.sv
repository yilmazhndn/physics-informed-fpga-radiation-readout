// Isolates the registered divider input to exhaustively test every attainable
// baseline sum against the simulator's independent unsigned integer division.
`timescale 1ns/1ps
module tb_divider;
    parameter integer SAMPLE_BITS=12, PRETRIGGER_SAMPLES=40, THRESHOLD_COUNTS=61;
    localparam integer SUM_W=SAMPLE_BITS+$clog2(PRETRIGGER_SAMPLES);
    localparam integer K2=(SUM_W+1)/2, K3=(SUM_W+2)/3;
    localparam integer MAX_SUM=((2**SAMPLE_BITS)-1)*PRETRIGGER_SAMPLES;
    reg clk=0,rst=1;
    always #2 clk=~clk;
    reg [SUM_W-1:0] injected_sum=0;
    reg inject_valid=0;
    nai59_peak_trigger_pipeline #(.SAMPLE_BITS(SAMPLE_BITS),.PRETRIGGER_SAMPLES(PRETRIGGER_SAMPLES),
        .THRESHOLD_COUNTS(THRESHOLD_COUNTS),.DIV_BITS_PER_STAGE(2)) p2
        (.clk(clk),.rst(rst),.sample_valid(1'b0),.event_start(1'b0),.sample_in({SAMPLE_BITS{1'b0}}));
    nai59_peak_trigger_pipeline #(.SAMPLE_BITS(SAMPLE_BITS),.PRETRIGGER_SAMPLES(PRETRIGGER_SAMPLES),
        .THRESHOLD_COUNTS(THRESHOLD_COUNTS),.DIV_BITS_PER_STAGE(3)) p3
        (.clk(clk),.rst(rst),.sample_valid(1'b0),.event_start(1'b0),.sample_in({SAMPLE_BITS{1'b0}}));
    integer expected[0:K2];
    reg valid_history[0:K2];
    integer j,n,checked2=0,checked3=0;
    always @(posedge clk) begin
        #0.001;
        if(rst) begin
            for(j=0;j<=K2;j=j+1) begin expected[j]=0;valid_history[j]=0;end
        end else begin
            for(j=K2;j>0;j=j-1) begin expected[j]=expected[j-1];valid_history[j]=valid_history[j-1];end
            expected[0]=injected_sum/PRETRIGGER_SAMPLES;
            valid_history[0]=inject_valid;
            if(valid_history[K2-1] && p2.quotient[K2-1] !== expected[K2-1])
                $fatal(1,"P2 exact quotient failed");
            if(valid_history[K3-1] && p3.quotient[K3-1] !== expected[K3-1])
                $fatal(1,"P3 exact quotient failed");
            if(valid_history[K2]) begin
                checked2=checked2+1;
                if(p2.average_pipe !== expected[K2][SAMPLE_BITS-1:0] ||
                   p2.threshold_pipe !== expected[K2]+THRESHOLD_COUNTS)
                    $fatal(1,"P2 average/threshold failed");
            end
            if(valid_history[K3]) begin
                checked3=checked3+1;
                if(p3.average_pipe !== expected[K3][SAMPLE_BITS-1:0] ||
                   p3.threshold_pipe !== expected[K3]+THRESHOLD_COUNTS)
                    $fatal(1,"P3 average/threshold failed");
            end
        end
    end
    initial begin
        force p2.sum_snapshot=injected_sum;
        force p3.sum_snapshot=injected_sum;
        repeat(4) @(negedge clk);
        rst=0;
        for(n=0;n<=MAX_SUM;n=n+1) begin
            injected_sum=n;inject_valid=1;
            @(negedge clk);
        end
        inject_valid=0;
        repeat(K2+3) @(negedge clk);
        if(checked2!=MAX_SUM+1 || checked3!=MAX_SUM+1) $fatal(1,"Incorrect test count");
        $display("DIVIDER PASS bits=%0d divisor=%0d exhaustive_inputs=%0d variants=2 mismatches=0",
            SAMPLE_BITS,PRETRIGGER_SAMPLES,MAX_SUM+1);
        $finish;
    end
endmodule
