# JINST revision reproducibility supplement

This supplement accompanies the revised manuscript and extends the original
workflow archive. Extract the ZIP and run the commands below from its root.
The three studies share the original HDL vectors where applicable.

## FPGA timing and functional regression

`revision_comment2/` contains the original, width-restricted and pipelined
RTL, testbenches and scripts. The eight routed Vivado report sets, their XDC
files and the comparison CSV are in `reports/JINST_Timing_Results_20261102/`.
The public copies of the reports have the workstation name redacted in the
headers. Timing data and constraints are preserved. The two
`verified_comparison` files summarize the results.

- Run functional regression with Python 3 and Icarus Verilog:
  `python revision_comment2/scripts/run_validation.py`.
- Re-extract the timing results:
  `python verify_reports.py reports/JINST_Timing_Results_20261102 timing_check`.
- Re-run the Vivado 2026.1 matrix on the Artix-7 xc7a35tcpg236-1:
  `vivado -mode batch -source revision_comment2/scripts/run_vivado_matrix.tcl`.

The reported closure concerns constrained internal paths. Board I/O timing
and physical FPGA operation were outside the study.

## Pulse-shape sensitivity

`revision_comment3/` contains the analysis, testbench, results and replay
vectors for the 3 x 3 grid of rise and decay parameters. Install NumPy and
pandas, make Icarus Verilog available, and run
`python revision_comment3/run_sensitivity.py`. The script writes results
under `revision_comment3/results/`. Use a fresh extraction to preserve the
packaged reference outputs. The original waveform labels, generator and
configuration are included under `waveforms/` and `scripts/`.

## Independent noise-only validation

Install dependencies with
`python -m pip install -r revision_comment4/requirements.txt`, then run
`python revision_comment4/run_noise_validation.py --output noise_reproduced`.
On Windows, the included `RUN_WINDOWS.cmd` can also launch the test.
`revision_comment4/reference_results/` contains the Windows run, including
the threshold calibration, held-out validation, signal efficiency, seed
namespace, input hashes and generated ADC hashes. The 600,000 noise-only
windows are regenerated from the seed rather than stored as arrays. The
statistical validation evaluates synthetic Gaussian noise. The integer
criterion implements the HDL arithmetic in software.

`SHA256SUMS.txt` records the hashes of the files in this supplement.
