#!/usr/bin/env python3
"""Nine paired pulse-shape conditions; reconstruct archived baseline first.

Uses the committed 100,000 event labels, the original seed/order and exact
float32 ADC quantization. No original data, thresholds or RTL are modified.
"""
from pathlib import Path
import concurrent.futures
import csv
import hashlib
import itertools
import json
import os
import shutil
import subprocess
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
OUT = HERE / 'results'
OUT.mkdir(exist_ok=True)
SEED = 20260618
BITS = (8, 10, 12)
THRESHOLDS = {8: 4, 10: 15, 12: 61}
TIME = np.arange(500) * 4.0


def shape(rise, decay, formula='product'):
    t = TIME - 200.
    h = np.zeros(500)
    m = t >= 0
    if formula == 'product':
        h[m] = (1. - np.exp(-t[m]/rise)) * np.exp(-t[m]/decay)
    else:
        h[m] = np.exp(-t[m]/decay) - np.exp(-t[m]/rise)
    return h / h.max()


def write_mem(path, values, width):
    path.write_text(''.join(f'{int(x):0{width}X}\n' for x in values.ravel()))


def references(q, bits, directory):
    directory.mkdir(parents=True, exist_ok=True)
    b = q[:, :40].astype(np.uint64).sum(axis=1)//40
    peak = q.max(axis=1)
    index = q.argmax(axis=1)
    trig = (q[:, 40:].astype(np.int64) >= b[:, None] + THRESHOLDS[bits]).any(axis=1)
    for name, values, width in [('samples', q, (bits+3)//4), ('baseline', b, (bits+3)//4),
                                 ('peak', peak, (bits+3)//4), ('index', index, 4), ('trigger', trig, 1)]:
        write_mem(directory/(name+'.mem'), values, width)


def main():
    labels = pd.read_csv(REPO/'waveforms/waveform_labels.csv')
    n = len(labels)
    assert n == 100000 and (labels.edep_nai_keV == 0).sum() == 109
    energy = labels.edep_nai_keV.to_numpy()
    nonzero = energy > 0
    rng = np.random.default_rng(SEED)
    gain = rng.normal(1., .015, n)
    amplitude = np.clip(.7 * energy / 59.5 * gain, 0, .95)
    assert np.max(abs(amplitude - labels.true_amplitude_norm.to_numpy())) < 1e-12
    # Verify which formula produced the archived raw integer samples.
    noise = rng.normal(0., .003, (1024, 500))
    verification = []
    for formula in ['product', 'difference']:
        a = np.clip(.1 + amplitude[:1024, None] * shape(20, 250, formula)[None, :] + noise, 0, 1).astype(np.float32)
        for bits in BITS:
            q = np.rint(a * (2**bits-1)).astype(np.uint16)
            archive = np.loadtxt(REPO/f'hdl_vectors/nai59_{bits}bit_flat.mem', dtype=np.uint16,
                                 converters={0: lambda x: int(x, 16)}).reshape(1024, 500)
            mismatches = int((q != archive).sum())
            verification.append({'formula':formula, 'adc_bits':bits, 'samples':q.size,
                                 'mismatches':mismatches})
            if formula == 'product': assert mismatches == 0
            else: assert mismatches > 0
    (OUT/'formula_verification.json').write_text(json.dumps(verification, indent=2)+'\n')
    # Same 1024 events in each case: all 109 existing zero-energy controls and
    # the first 915 nonzero events in original order. No new noise controls.
    replay_ids = np.r_[np.flatnonzero(~nonzero), np.flatnonzero(nonzero)[:915]]
    assert len(replay_ids) == len(set(replay_ids)) == 1024
    labels.iloc[replay_ids].to_csv(OUT/'replay_event_selection.csv', index=False)
    nominal = {}
    rows = []
    conditions = [(20,250)] + [c for c in itertools.product([18,20,22],[225,250,275]) if c != (20,250)]
    for rise, decay in conditions:
        h = shape(rise, decay)
        rng = np.random.default_rng(SEED)
        assert np.array_equal(rng.normal(1., .015, n), gain)
        work = {bits: {'energy':np.zeros(n,dtype=np.float32), 'peak_index':np.zeros(n,dtype=np.int16),
                       'trigger':np.zeros(n,dtype=bool), 'float_trigger':np.zeros(n,dtype=bool),
                       'replay':np.zeros((1024,500),dtype=np.uint16)} for bits in BITS}
        for first in range(0, n, 2048):
            last = min(first+2048,n)
            noise = rng.normal(0., .003, (last-first,500))
            analog = np.clip(.1 + amplitude[first:last,None] * h[None,:] + noise,0,1).astype(np.float32)
            selected = (replay_ids >= first) & (replay_ids < last)
            for bits in BITS:
                q = np.rint(analog * (2**bits-1)).astype(np.uint16)
                normalized = q.astype(np.float32) / (2**bits-1)
                amp = normalized.max(axis=1) - normalized[:,:40].mean(axis=1)
                w = work[bits]
                w['energy'][first:last] = amp/.7*59.5
                w['peak_index'][first:last] = q.argmax(axis=1)
                baseline = q[:,:40].astype(np.uint64).sum(axis=1)//40
                w['trigger'][first:last] = (q[:,40:].astype(np.int64) >= baseline[:,None]+THRESHOLDS[bits]).any(axis=1)
                w['float_trigger'][first:last] = amp >= .015
                w['replay'][selected] = q[replay_ids[selected]-first]
        for bits in BITS:
            w = work[bits]
            if (rise,decay)==(20,250): nominal[bits] = w
            err = w['energy'][nonzero]-energy[nonzero]
            idx_delta = (w['peak_index'][nonzero]-nominal[bits]['peak_index'][nonzero])*4
            tag = f'r{rise}_d{decay}_b{bits}'
            references(w['replay'], bits, OUT/'vectors'/tag)
            rows.append({'case':tag, 'tau_rise_ns':rise,'tau_decay_ns':decay,'adc_bits':bits,
                         'events':n, 'nonzero_events':int(nonzero.sum()),'zero_events':int((~nonzero).sum()),
                         'threshold_counts':THRESHOLDS[bits], 'noise_sigma':.003,
                         'nonzero_energy_rmse_keV':float(np.sqrt(np.mean(err**2))),
                         'nonzero_energy_bias_keV':float(np.mean(err)),
                         'nonzero_energy_mae_keV':float(np.mean(abs(err))),
                         'integer_trigger_efficiency_percent':float(100*w['trigger'][nonzero].mean()),
                         'integer_false_triggers_count':int(w['trigger'][~nonzero].sum()),
                         'float_trigger_efficiency_percent':float(100*w['float_trigger'][nonzero].mean()),
                         'noiseless_peak_time_ns':float(TIME[h.argmax()]),
                         'paired_peak_time_shift_mean_ns':float(np.mean(idx_delta)),
                         'paired_peak_time_shift_abs_p95_ns':float(np.percentile(abs(idx_delta),95)),
                         'shape_nrmsd_vs_nominal':float(np.sqrt(np.mean((h-shape(20,250))**2))),
                         'hdl_replay_events':1024})
        print(f'Waveforms and references ready: rise={rise}, decay={decay}',flush=True)
    for row in rows:
        base = next(r for r in rows if r['adc_bits']==row['adc_bits'] and r['tau_rise_ns']==20 and r['tau_decay_ns']==250)
        row['energy_rmse_change_percent'] = 100*(row['nonzero_energy_rmse_keV']/base['nonzero_energy_rmse_keV']-1)
    old = pd.read_csv(REPO/'waveforms/adc_readout_metrics_summary.csv')
    for row in rows[:3]:
        before = old[(old.adc_bits==row['adc_bits']) & (old.event_subset=='nonzero')].iloc[0]
        assert abs(row['nonzero_energy_rmse_keV']-before.rmse_keV)<1e-7
    pd.DataFrame(rows).to_csv(OUT/'sensitivity_metrics.csv',index=False)
    (OUT/'protocol.json').write_text(json.dumps({'seed':SEED,'noise_sigma':.003,'normalization':'sampled peak normalized separately for each pulse shape',
        'conditions':conditions,'adc_bits':BITS,'threshold_counts':THRESHOLDS,'reference_energy_keV':59.5,'full_energy_amplitude':.7,
        'sampling_interval_ns':4,'window_samples':500,'pretrigger_samples':40,'replay_events_per_case':1024,
        'replay_selection':'all 109 existing zero-energy events plus first 915 nonzero events',
        'scope':'shape sensitivity only; no charge/amplitude covariance, measured data, or physical FPGA experiments',
        'sha256':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [REPO/'waveforms/waveform_labels.csv',REPO/'waveforms/waveform_generation_parameters.csv', REPO/'scripts/generate_nai59_adc_waveforms.py']}
    },indent=2)+'\n')
    run_hdl(rows)


def run_hdl(rows):
    iverilog = os.environ.get('IVERILOG',shutil.which('iverilog') or 'iverilog')
    vvp = os.environ.get('VVP',shutil.which('vvp') or 'vvp')
    base = [iverilog]
    if os.environ.get('IVL_ROOT'): base += ['-B',os.environ['IVL_ROOT']]
    def job(row):
        tag = row['case']; executable = OUT/(tag+'.vvp')
        command = base+['-g2012','-s','tb_sensitivity',f'-Ptb_sensitivity.BITS={row["adc_bits"]}',
                         f'-Ptb_sensitivity.THRESHOLD={row["threshold_counts"]}','-o',str(executable),
                         str(REPO/'revision_comment2/rtl/nai59_peak_trigger_original.v'),
                         str(REPO/'revision_comment2/rtl/nai59_peak_trigger_pipeline.v'),str(HERE/'tb_sensitivity.sv')]
        c = subprocess.run(command,capture_output=True,text=True)
        if c.returncode: raise RuntimeError(c.stdout+c.stderr)
        r = subprocess.run([vvp,str(executable),f'+VECTORS={OUT/"vectors"/tag}'],capture_output=True,text=True)
        (OUT/(tag+'.log')).write_text(c.stdout+c.stderr+r.stdout+r.stderr)
        if r.returncode or 'PASS original=1024 pipeline3=1024' not in r.stdout: raise RuntimeError(tag+'\n'+r.stdout+r.stderr)
        print('HDL PASS '+tag,flush=True)
        return {'case':tag,'adc_bits':row['adc_bits'],'original_events':1024,'pipeline3_events':1024,'mismatches':0}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(job,rows))
    pd.DataFrame(results).to_csv(OUT/'hdl_validation.csv',index=False)
    print('ALL 27 HDL CASES PASS',flush=True)


if __name__=='__main__': main()
