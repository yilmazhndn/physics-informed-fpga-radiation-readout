`timescale 1ns/1ps
module tb_sensitivity;
    parameter integer BITS=12, THRESHOLD=61;
    localparam integer EVENTS=1024, SAMPLES=500;
    localparam integer LATENCY=(BITS+6+2)/3+2;
    reg clk=0;
    always #2 clk=~clk;
    reg rst=1, start=0, valid=0;
    reg [BITS-1:0] sample=0;
    wire done[0:1], trigger_out[0:1];
    wire [BITS-1:0] peak[0:1], baseline[0:1];
    wire [15:0] index[0:1];
`define PARAMS .SAMPLE_BITS(BITS),.N_SAMPLES(SAMPLES),.PRETRIGGER_SAMPLES(40),.THRESHOLD_COUNTS(THRESHOLD)
`define PORTS(i) .clk(clk),.rst(rst),.event_start(start),.sample_valid(valid),.sample_in(sample),.event_done(done[i]),.triggered(trigger_out[i]),.peak_count(peak[i]),.peak_index(index[i]),.baseline_count(baseline[i])
    nai59_peak_trigger_original #(`PARAMS) original_dut (`PORTS(0));
    nai59_peak_trigger_pipeline #(`PARAMS,.DIV_BITS_PER_STAGE(3)) pipeline_dut (`PORTS(1));
`undef PARAMS
`undef PORTS
    reg [BITS-1:0] samples[0:EVENTS*SAMPLES-1];
    reg [BITS-1:0] expected_peak[0:EVENTS-1], expected_baseline[0:EVENTS-1];
    reg [15:0] expected_index[0:EVENTS-1];
    reg expected_trigger[0:EVENTS-1];
    integer checked[0:1];
    integer original_cycle[0:EVENTS-1];
    integer cycles=0, d, e, s;
    string directory;
    always @(posedge clk) begin
        #0.001;
        if (!rst) begin
            cycles=cycles+1;
            for(d=0;d<2;d=d+1) if(done[d]) begin
                if(checked[d]>=EVENTS) $fatal(1,"Extra event completion");
                if(peak[d] !== expected_peak[checked[d]] || baseline[d] !== expected_baseline[checked[d]] ||
                   index[d] !== expected_index[checked[d]] || trigger_out[d] !== expected_trigger[checked[d]])
                    $fatal(1,"Reference mismatch DUT=%0d event=%0d",d,checked[d]);
                if(d==0) original_cycle[checked[d]]=cycles;
                else if(cycles-original_cycle[checked[d]]!=LATENCY) $fatal(1,"Output latency mismatch");
                checked[d]=checked[d]+1;
            end
        end
    end
    initial begin
        checked[0]=0;checked[1]=0;
        if(!$value$plusargs("VECTORS=%s",directory)) $fatal(1,"Missing vectors");
        $readmemh({directory,"/samples.mem"},samples);
        $readmemh({directory,"/baseline.mem"},expected_baseline);
        $readmemh({directory,"/peak.mem"},expected_peak);
        $readmemh({directory,"/index.mem"},expected_index);
        $readmemh({directory,"/trigger.mem"},expected_trigger);
        repeat(4) @(negedge clk);
        rst=0;
        for(e=0;e<EVENTS;e=e+1) begin
            @(negedge clk);start=1;valid=0;
            for(s=0;s<SAMPLES;s=s+1) begin
                @(negedge clk);start=0;valid=1;sample=samples[e*SAMPLES+s];
            end
            @(negedge clk);valid=0;
            repeat(LATENCY+2) @(negedge clk);
        end
        if(checked[0]!=EVENTS || checked[1]!=EVENTS) $fatal(1,"Missing completions");
        $display("PASS original=%0d pipeline3=%0d bits=%0d latency=%0d",checked[0],checked[1],BITS,LATENCY);
        $finish;
    end
endmodule
